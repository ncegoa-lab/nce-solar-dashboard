NCE Solar Dashboard multi-user PostgreSQL update
Build: 2026-07-13-solis-weekly-history-fix-v55

Upload these files to GitHub/Render:
- solar_live_app.py
- solar_performance_report_app.py
- manage_solar_users.py
- requirements_web.txt
- requirements.txt
- render.yaml
- Dockerfile
- Procfile
- migrations/001_solar_app_users.sql

Required Render environment variables:
- DATABASE_URL: Render PostgreSQL internal connection string
- NCE_SESSION_SECRET: long random secret
- NCE_APP_USER: admin
- NCE_APP_PASSWORD: initial admin password for first database seed
- SOLAR_OUTPUT_DIR: /app/reports
- Existing inverter credentials/API variables as before

After deploy:
1. Open the dashboard and login as admin.
2. Click Users in the header.
3. Create Manager, Customer, and Viewer users.
4. Assign one or more plant keys to each non-admin user.
5. Customers can click Change Password after login.

Notes:
- PostgreSQL tables are created automatically at startup.
- Existing admin is seeded into PostgreSQL when the user table is empty.
- Passwords are stored as PBKDF2 hashes.
- Non-admin users can only see assigned plants and their own reports.
- Solis weekly generation is calculated from dashboard history when Solis API returns no weekly value.
